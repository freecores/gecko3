The following files were generated for 'fifo_U2X_2C_1024B' in directory 
/home/habea2/Geccko3com/gecko3com_v04/:

fifo_U2X_2C_1024B_xmdf.tcl:
   Please see the core data sheet.

fifo_U2X_2C_1024B_flist.txt:
   Text file listing all of the output files produced when a customized
   core was generated in the CORE Generator.

fifo_U2X_2C_1024B_fifo_generator_v3_3_xst_1.ndf:
   Optional output file produced for cores that generate NGC files.
   The NDF files allow third party synthesis tools to infer resource
   utilization and timing from the NGC files associated with these new
   cores.

fifo_U2X_2C_1024B.vho:
   VHO template file containing code that can be used as a model for
   instantiating a CORE Generator module in a VHDL design.

fifo_U2X_2C_1024B.vhd:
   VHDL wrapper file provided to support functional simulation. This
   file contains simulation model customization data that is passed to
   a parameterized simulation model for the core.

fifo_U2X_2C_1024B_readme.txt:
   Text file indicating the files generated and how they are used.

fifo_U2X_2C_1024B_padded.edn:
   EDIF wrapper file generated for a core when the Generate netlist
   wrapper with IO pads project option is enabled. The file adds input
   pads and output pads to the core, allowing you to process the
   generated core through the Xilinx design flow as if it were a
   complete chip design.

fifo_U2X_2C_1024B.asy:
   Graphical symbol information file. Used by the ISE tools and some
   third party tools to create a symbol representing the core.

fifo_U2X_2C_1024B_for.v:
   Unisim Verilog file containing the information required to support formal
   verification of the module.

fifo_U2X_2C_1024B.ngc:
   Binary Xilinx implementation netlist file containing the information
   required to implement the module in a Xilinx (R) FPGA.

fifo_U2X_2C_1024B.sym:
   Please see the core data sheet.

fifo_U2X_2C_1024B.xco:
   CORE Generator input file containing the parameters used to
   regenerate a core.


Please see the Xilinx CORE Generator online help for further details on
generated files and how to use them.

