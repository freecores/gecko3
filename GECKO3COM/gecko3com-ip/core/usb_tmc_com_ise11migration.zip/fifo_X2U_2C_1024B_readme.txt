The following files were generated for 'fifo_X2U_2C_1024B' in directory 
/home/habea2/Geccko3com/gecko3com_v04/:

fifo_X2U_2C_1024B.ngc:
   Binary Xilinx implementation netlist file containing the information
   required to implement the module in a Xilinx (R) FPGA.

fifo_X2U_2C_1024B_flist.txt:
   Text file listing all of the output files produced when a customized
   core was generated in the CORE Generator.

fifo_X2U_2C_1024B.asy:
   Graphical symbol information file. Used by the ISE tools and some
   third party tools to create a symbol representing the core.

fifo_X2U_2C_1024B.vhd:
   VHDL wrapper file provided to support functional simulation. This
   file contains simulation model customization data that is passed to
   a parameterized simulation model for the core.

fifo_X2U_2C_1024B.vho:
   VHO template file containing code that can be used as a model for
   instantiating a CORE Generator module in a VHDL design.

fifo_X2U_2C_1024B.xco:
   CORE Generator input file containing the parameters used to
   regenerate a core.

fifo_X2U_2C_1024B_xmdf.tcl:
   Please see the core data sheet.

fifo_X2U_2C_1024B.v:
   Verilog wrapper file provided to support functional simulation.
   This file contains simulation model customization data that is
   passed to a parameterized simulation model for the core.

fifo_X2U_2C_1024B.veo:
   VEO template file containing code that can be used as a model for
   instantiating a CORE Generator module in a Verilog design.

fifo_X2U_2C_1024B.sym:
   Please see the core data sheet.

fifo_X2U_2C_1024B_readme.txt:
   Text file indicating the files generated and how they are used.


Please see the Xilinx CORE Generator online help for further details on
generated files and how to use them.

